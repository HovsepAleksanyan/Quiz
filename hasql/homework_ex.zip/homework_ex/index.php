<?php
require_once 'storage/base.php';
$dataBase = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);


$sqlTableCreate = "CREATE TABLE `my_db`.`the_users`
(
    `id` INT NOT NULL AUTO_INCREMENT ,
    `name` VARCHAR(10) NOT NULL ,
    `surname` VARCHAR(15) NOT NULL ,
    `age` INT NOT NULL ,
    `gender` VARCHAR(6) NOT NULL ,
    `income` INT NOT NULL ,
    `password` VARCHAR(15) NOT NULL ,
    PRIMARY KEY (`id`)
) 
ENGINE = InnoDB CHARSET=utf8mb3 COLLATE utf8mb3_general_ci;";
//create table
mysqli_query($dataBase, $sqlTableCreate);

//SELECT
$sqlGetData = "SELECT * FROM `my_db`.`the_users`";
$usersData = mysqli_query($dataBase, $sqlGetData);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>

<body>
    <table class="table container mt-3 text-center shadow-lg mb-5">
        <thead>
            <tr>
                <th>Name</th>
                <th>Surname</th>
                <th>Age</th>
                <th>Gender</th>
                <th>Income</th>
                <th>Password</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($usersData)) : ?>
                <tr>
                    <td><?php echo $row['name'] ?></td>
                    <td><?php echo $row['surname'] ?></td>
                    <td><?php echo $row['age'] ?></td>
                    <td><?php echo $row['gender'] ?></td>
                    <td><?php echo $row['income'] ?></td>
                    <td><?php echo $row['password'] ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

<a href="queries/insertData.php" class="btn btn-outline-success">Insert Into</a>


</body>

</html>

<?php
mysqli_close($dataBase);
?>